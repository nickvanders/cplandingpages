import Header from "@/components/landing/Header";
import Hero from "@/components/landing/Hero";
import GoldStandard from "@/components/landing/GoldStandard";
import TherapeuticProcess from "@/components/landing/TherapeuticProcess";
import SkillsAndOutcomes from "@/components/landing/SkillsAndOutcomes";
import Team from "@/components/landing/Team";
import ContactForm from "@/components/landing/ContactForm";
import Footer from "@/components/landing/Footer";

export default function Home() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToProcess = () => {
    const element = document.querySelector("#process");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onBookClick={scrollToContact} />
      <main>
        <Hero 
          onBookClick={scrollToContact} 
          onLearnMoreClick={scrollToProcess} 
        />
        <GoldStandard />
        <TherapeuticProcess onBookClick={scrollToContact} />
        <SkillsAndOutcomes onBookClick={scrollToContact} />
        <Team />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}
